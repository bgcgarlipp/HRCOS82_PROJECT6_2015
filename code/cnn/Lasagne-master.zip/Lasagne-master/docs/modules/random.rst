:mod:`lasagne.random`
=====================

.. automodule:: lasagne.random

.. autofunction:: get_rng
.. autofunction:: set_rng

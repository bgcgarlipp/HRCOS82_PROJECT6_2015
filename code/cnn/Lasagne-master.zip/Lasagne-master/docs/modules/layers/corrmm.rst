:mod:`lasagne.layers.corrmm`
----------------------------

.. automodule:: lasagne.layers.corrmm
    :members:


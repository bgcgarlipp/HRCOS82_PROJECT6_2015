:mod:`lasagne.layers.dnn`
-------------------------

.. automodule:: lasagne.layers.dnn
    :members:


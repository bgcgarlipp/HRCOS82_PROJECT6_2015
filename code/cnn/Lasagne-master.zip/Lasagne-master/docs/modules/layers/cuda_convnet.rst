:mod:`lasagne.layers.cuda_convnet`
----------------------------------

.. automodule:: lasagne.layers.cuda_convnet
    :members:


Shape layers
------------

.. automodule:: lasagne.layers.shape

.. currentmodule:: lasagne.layers

.. autoclass:: ReshapeLayer
    :members:

.. autoclass:: reshape

.. autoclass:: FlattenLayer
    :members:

.. autoclass:: flatten

.. autoclass:: DimshuffleLayer
    :members:

.. autoclass:: dimshuffle

.. autoclass:: PadLayer
    :members:

.. autoclass:: pad

.. autoclass:: SliceLayer


:mod:`nolearn.metrics`
----------------------

.. automodule:: nolearn.metrics

  .. autofunction:: multiclass_logloss
  .. autofunction:: learning_curve
  .. autofunction:: learning_curve_logloss

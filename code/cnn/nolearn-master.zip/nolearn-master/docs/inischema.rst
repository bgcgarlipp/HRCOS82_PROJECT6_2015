:mod:`nolearn.inischema`
------------------------

.. automodule:: nolearn.inischema

  .. autofunction:: parse_config

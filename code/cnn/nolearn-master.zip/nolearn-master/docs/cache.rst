:mod:`nolearn.cache`
--------------------

.. automodule:: nolearn.cache

  .. autofunction:: cached
